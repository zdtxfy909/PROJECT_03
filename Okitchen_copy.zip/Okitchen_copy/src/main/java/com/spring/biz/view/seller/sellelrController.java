package com.spring.biz.view.seller;

public class sellelrController {
	//판매자 마이페이지로 이동
	
	
}
