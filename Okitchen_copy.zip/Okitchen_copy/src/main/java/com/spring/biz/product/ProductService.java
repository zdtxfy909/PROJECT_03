package com.spring.biz.product;


public interface ProductService {
	//CRUD 기능 구현 메소드 정의
	void registerProduct(RegisterProdVO vo); //상품등록
	
	
}
