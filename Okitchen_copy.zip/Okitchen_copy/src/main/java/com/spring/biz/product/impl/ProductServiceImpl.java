package com.spring.biz.product.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.biz.product.ProductService;
import com.spring.biz.product.RegisterProdVO;

//@Service : @Component 상속 확장 어노테이션
//비즈니스 로직 처리 서비스 영역에 사용
@Service("productService")
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductDAO productDAO;
	
	public ProductServiceImpl() {
		System.out.println(">> ProductServiceImpl() 객체 생성");
	}

	@Override
	public void registerProduct(RegisterProdVO vo) {
		productDAO.registerProduct(vo);
	}
	
	
	
}
