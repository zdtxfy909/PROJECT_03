package com.spring.biz.view.product;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.swing.Spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.spring.biz.product.ProductService;
import com.spring.biz.product.RegisterProdVO;

@Controller
@RequestMapping("/product")
public class productController {
	
	private ProductService productService;
	
	public productController() {
		System.out.println("=========> productController 객체 생성");
	}
	
	@Autowired
	public productController(ProductService productService) {
		System.out.println("=========> productController(productService) 객체 생성");
		System.out.println("::: ProductService productService : " + productService);
		this.productService = productService;
	}
	
	@GetMapping("/productList.do")
	private String productList() {
		System.out.println("======> productController.productList() 실행");
		System.out.println(">>>  화면 이동 - productList()");
		
		return "seller/productList";
	}
	
	//상품등록하기
	@RequestMapping("/insertProduct.do")
	public String insertProduct(RegisterProdVO vo, @RequestParam("productPhotoFiles") List<MultipartFile> productPhotoFiles, HttpServletRequest request) 
			throws IllegalStateException, IOException {
		System.out.println(">>> 상품등록");
		System.out.println("vo : " + vo);
		
		MultipartFile titleImage = vo.getImageFile();
		//MultipartFile detailImage = vo.getProductPhotoFile();
		System.out.println(">> titleImage : " + titleImage);
		//System.out.println(">> detailImage : " + detailImage);
		
		//대표이미지
		if (titleImage == null) {
			System.out.println("::: uploadFile 파라미터가 전달되지 않은 경우");
		} else if (titleImage.isEmpty()) {
			System.out.println("::: 전달받은 파일 데이터가 없는 경우");
		} else { //업로드 파일이 존재하는 경우 false
			System.out.println("titleImage.isEmpty() : " + titleImage.isEmpty());
			//System.out.println("detailImage.isEmpty() : " + detailImage.isEmpty());
			
			//원본파일명 구하기
			String titleFilename = titleImage.getOriginalFilename();
			//String detailFilename = detailImage.getOriginalFilename();
	        System.out.println("::: titleFilename 원본파일명 : " + titleFilename);
	        //System.out.println("::: detailFilename 원본파일명 : " + detailFilename);

			//저장파일명 구하기
			String savedFilename = UUID.randomUUID().toString();
			//String savedDetailFilename = UUID.randomUUID().toString();
			System.out.println("::: titleImage 저장파일명 : " + savedFilename);
			//System.out.println("::: detailImage 저장파일명 : " + savedDetailFilename);
			
			// 서블릿 컨텍스트의 실제 경로를 얻어옴
			String uploadDir = request.getServletContext().getRealPath("/productImage/title");
			//String uploadDir2 = request.getServletContext().getRealPath("/productImage/detail");
			
			// 저장할 폴더 경로와 파일명을 합침
			String destPathFile = uploadDir + File.separator + savedFilename;
			//String destPathFile2 = uploadDir2 + File.separator + savedDetailFilename;

			
			//물리적 파일 복사
			//uploadFile.transferTo(new File("C:/MyStudy/temp/" + savedFilename));
			//String destPathFile = "C:/MyStudy/temp/" + savedFilename;
			//String destDetailPathFile = "C:/MyStudy/temp/detail/" + savedDetailFilename;
			
			titleImage.transferTo(new File(destPathFile));
			//detailImage.transferTo(new File(destPathFile2));
			
			vo.setImage(savedFilename);
			//vo.setProductPhoto(savedDetailFilename);
		}
		
		//상세이미지
		if (productPhotoFiles != null && !productPhotoFiles.isEmpty()) {
	        for (MultipartFile productPhotoFile : productPhotoFiles) {
	            if (productPhotoFile != null && !productPhotoFile.isEmpty()) {
	                // 원본 파일명 구하기
	                String detailFilename = productPhotoFile.getOriginalFilename();
	                System.out.println("::: detailFilename 원본 파일명: " + detailFilename);

	                // 저장 파일명 구하기
	                String savedDetailFilename = UUID.randomUUID().toString();
	                System.out.println("::: detailImage 저장 파일명: " + savedDetailFilename);

	                // 서블릿 컨텍스트의 실제 경로를 얻어옴
	                String uploadDir2 = request.getServletContext().getRealPath("/productImage/detail");

	                // 저장할 폴더 경로와 파일명을 합침
	                String destPathFile2 = uploadDir2 + File.separator + savedDetailFilename;

	                // 물리적 파일 복사
	                productPhotoFile.transferTo(new File(destPathFile2));

	                vo.setProductPhoto(savedDetailFilename);
	                System.out.println("vo : " + vo);
	                productService.registerProduct(vo);
	            }
	        }
	    }
        System.out.println("vo : " + vo);

		
		return "seller/productList"; //판매자의 내 상품 조회하기 페이지로 이동
	}
	
	//[상품등록하기] 클릭시 화면전환
	@GetMapping("/registerProduct.do")
	private String registerProduct() {
		System.out.println("======> productController.registerProduct() 실행");
		System.out.println(">>>  화면 이동 - registerProduct()");
		
		return "seller/registerProduct";
	}
	
	
	
	
}
