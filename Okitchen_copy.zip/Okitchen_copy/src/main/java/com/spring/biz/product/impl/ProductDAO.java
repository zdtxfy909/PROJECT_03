package com.spring.biz.product.impl;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.spring.biz.product.RegisterProdVO;

@Repository
public class ProductDAO {
	
	  @Autowired 
	  private SqlSessionTemplate mybatis;
	  
	  public ProductDAO() { System.out.println(">>> ProductDAO() 객체 생성"); }
	  
	  //상품등록 
	  public void registerProduct(RegisterProdVO vo) {
		  System.out.println("===> Mybatis로 registerProduct() 실행"); 
		  
		  mybatis.insert("registerProdDAO.insertProduct", vo);
		  mybatis.insert("registerProdDAO.insertOption", vo);
		  mybatis.insert("registerProdDAO.insertProdImage", vo);
	  }
	 
}
