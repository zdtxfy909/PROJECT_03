package com.spring.biz.vo;

import java.sql.Date;

public class UsersVO {
	private String userId;
	private String userName;
	private String userPassword;
	private String userEmail;
	private String userBirth;
	private String userStatus;
	private Date userDate;
	private String userGender;
	private String userAddress;
	private String userPhonenum;
}
